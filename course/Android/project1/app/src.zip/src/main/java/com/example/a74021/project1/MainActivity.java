package com.example.a74021.project1;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements View.OnClickListener {

    private Button mTabZhuye;
    private Button mTabMap;
    private Button mTabPicture;
    private Button mTabSetting;
    private Button addpic;
    private ContentFragment mWeixin;
    private MapFragment mMap;
    private RecyclerFragment mPicture;
    private settingFragment mSetting;
    //RecyclerView mRecyclerView;
    public static List<Image> mList=new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        //图片id
        List<Integer> resIds;
        initData();
        //初始化控件和声明时间
        mTabZhuye=(Button) findViewById(R.id.tab_bottom_zhuye);
        mTabMap=(Button) findViewById(R.id.tab_bottom_map);
        mTabPicture=(Button)findViewById(R.id.tab_bottom_picture);
        mTabSetting=(Button)findViewById(R.id.tab_bottom_setting);
        mTabSetting.setOnClickListener(this);
        mTabPicture.setOnClickListener(this);
        mTabZhuye.setOnClickListener(this);
        mTabMap.setOnClickListener(this);
        addpic=(Button)findViewById(R.id.add_pic) ;
        //设置默认的Fragment
        setDefaultFragment();
        addpic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"上传照片功能待开发", Toast.LENGTH_SHORT).show();
            }
        });



    }//oncreate

    private void initData(){

        mList.add(new Image(R.drawable.img02));
        mList.add(new Image(R.drawable.img03));
        mList.add(new Image(R.drawable.img04));
        mList.add(new Image(R.drawable.img05));
        mList.add(new Image(R.drawable.img06));
        mList.add(new Image(R.drawable.img07));
        mList.add(new Image(R.drawable.img08));
        mList.add(new Image(R.drawable.img09));
        mList.add(new Image(R.drawable.img10));
        mList.add(new Image(R.drawable.img02));
        mList.add(new Image(R.drawable.img03));
        mList.add(new Image(R.drawable.img04));
        mList.add(new Image(R.drawable.img05));
        mList.add(new Image(R.drawable.img06));
        mList.add(new Image(R.drawable.img07));
        mList.add(new Image(R.drawable.img08));
        mList.add(new Image(R.drawable.img02));
        mList.add(new Image(R.drawable.img03));
        mList.add(new Image(R.drawable.img04));
        mList.add(new Image(R.drawable.img05));
        mList.add(new Image(R.drawable.img06));
        mList.add(new Image(R.drawable.img07));
        mList.add(new Image(R.drawable.img08));
        mList.add(new Image(R.drawable.img09));
        mList.add(new Image(R.drawable.img10));
        mList.add(new Image(R.drawable.img02));
        mList.add(new Image(R.drawable.img03));
        mList.add(new Image(R.drawable.img04));
        mList.add(new Image(R.drawable.img05));
        mList.add(new Image(R.drawable.img06));
        mList.add(new Image(R.drawable.img07));
        mList.add(new Image(R.drawable.img08));
    }


    class Image{
        int imgId;
        public int getImgId(){return imgId;}
        public Image(int imgId){
            this.imgId = imgId;
        }
    }


    private void setDefaultFragment()
    {
        FragmentManager fm=getFragmentManager();
        FragmentTransaction transaction=fm.beginTransaction();
        mWeixin=new ContentFragment();
        transaction.replace(R.id.id_content,mWeixin);
        transaction.commit();
        mTabZhuye.getBackground().setAlpha(255);
        mTabSetting.getBackground().setAlpha(125);
        mTabPicture.getBackground().setAlpha(125);
        mTabMap.getBackground().setAlpha(125);
    }

    @Override
    public void onClick(View v)
    {
        FragmentManager fm=getFragmentManager();
        FragmentTransaction transaction=fm.beginTransaction();
        transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        switch (v.getId())
        {
            case R.id.tab_bottom_zhuye:
                mTabZhuye.getBackground().setAlpha(255);
                mTabSetting.getBackground().setAlpha(125);
                mTabPicture.getBackground().setAlpha(125);
                mTabMap.getBackground().setAlpha(125);
                if (mWeixin==null)
                {
                    mWeixin=new ContentFragment();
                }
                //使用当前Fragment的布局代替id_content的控件
                transaction.replace(R.id.id_content,mWeixin);
                break;
            case R.id.tab_bottom_picture:
                mTabZhuye.getBackground().setAlpha(125);
                mTabSetting.getBackground().setAlpha(125);
                mTabPicture.getBackground().setAlpha(255);
                mTabMap.getBackground().setAlpha(125);
                if (mPicture==null)
                {
                    mPicture=new RecyclerFragment();
                }
                transaction.replace(R.id.id_content,mPicture);
                break;
            case R.id.tab_bottom_map:
                mTabZhuye.getBackground().setAlpha(125);
                mTabSetting.getBackground().setAlpha(125);
                mTabPicture.getBackground().setAlpha(125);
                mTabMap.getBackground().setAlpha(255);
                if(mMap==null)
                {
                    mMap=new MapFragment();
                }
                transaction.replace(R.id.id_content,mMap);

                break;
            case R.id.tab_bottom_setting:
                mTabZhuye.getBackground().setAlpha(125);
                mTabSetting.getBackground().setAlpha(255);
                mTabPicture.getBackground().setAlpha(125);
                mTabMap.getBackground().setAlpha(125);
                if (mSetting==null)
                {
                    mSetting=new settingFragment();
                }
                transaction.replace(R.id.id_content,mSetting);
                break;
        }
         //transaction.addToBackStack();
        //事务提交
        transaction.commit();
    }






}
